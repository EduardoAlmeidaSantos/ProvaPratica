﻿namespace MinhaAgenda
{
    class Program
    {
        static void MostrarCabecalho()
        {
            Console.Clear();
            Console.WriteLine("Nome Completo: Eduardo Almeida");
            Console.WriteLine("Turma: INF07");
            Console.WriteLine("Turno: Matutino");
        }
        static int ExibirMenu()
        {
            int op = 0;
            Console.Clear();
            Console.WriteLine("Minha Agenda");
            Console.WriteLine("Exibir dados - 1");
            Console.WriteLine("Inserir contato - 2");
            Console.WriteLine("Alterar contato - 3");
            Console.WriteLine("Excluir contato - 4");
            Console.WriteLine("Localizar contato - 5");
            Console.WriteLine("Sair - 6");
            Console.Write("Opção:");
            op = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            return op;
        }

        static void ExibirContato(String[] nome, String[] insta, String[] bairro, String[] cidade, int[] idade, int[] mesAniversario, String[] profissao, int tl)
        {
            Console.WriteLine("Exibir Contatos");
            for (int i = 0; i < tl; i++)
            {
                Console.WriteLine("Nome: {0} - Insta: {1} - Bairro: {2} - Cidade: {3} - Idade: {4} - Mês Aniversário: {5} - Profissão: {6}",
                    nome[i], insta[i], bairro[i], cidade[i], idade[i], mesAniversario[i], profissao[i]);
            }
            Console.ReadKey();
        }

        static void InserirContato(ref String[] nome, ref String[] insta, ref String[] bairro, ref String[] cidade, ref int[] idade, ref int[] mesAniversario, ref String[] profissao, ref int tl)
        {
            try
            {
                Console.WriteLine("Inserir Contato");
                Console.Write("Nome: ");
                string novoNome = Console.ReadLine();
                Console.Write("Insta: ");
                string novoInsta = Console.ReadLine();
                Console.Write("Bairro: ");
                string novoBairro = Console.ReadLine();
                Console.Write("Cidade: ");
                string novaCidade = Console.ReadLine();
                Console.Write("Idade: ");
                int novaIdade = Convert.ToInt32(Console.ReadLine());
                Console.Write("Mês de Aniversário: ");
                int novoMesAniversario = Convert.ToInt32(Console.ReadLine());
                Console.Write("Profissão: ");
                string novaProfissao = Console.ReadLine();

                int pos = LocalizarContato(insta, tl, novoInsta);

                if (pos == -1)
                {
                    nome[tl] = novoNome;
                    insta[tl] = novoInsta;
                    bairro[tl] = novoBairro;
                    cidade[tl] = novaCidade;
                    idade[tl] = novaIdade;
                    mesAniversario[tl] = novoMesAniversario;
                    profissao[tl] = novaProfissao;
                    tl++;
                }
                else
                {
                    Console.WriteLine("Contato já cadastrado");
                }
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine("Erro: " + e.Message);
                Console.ReadKey();
            }
        }

        static void AlterarContato(ref String[] nome, ref String[] insta, ref String[] bairro, ref String[] cidade, ref int[] idade, ref int[] mesAniversario, ref String[] profissao, int tl)
        {
            Console.WriteLine("Alterar Contato");
            Console.Write("Insta do contato a ser alterado: ");
            string instaContato = Console.ReadLine();

            int pos = LocalizarContato(insta, tl, instaContato);

            if (pos != -1)
            {
                Console.Write("Novo Nome: ");
                nome[pos] = Console.ReadLine();
                Console.Write("Novo Insta: ");
                insta[pos] = Console.ReadLine();
                Console.Write("Novo Bairro: ");
                bairro[pos] = Console.ReadLine();
                Console.Write("Nova Cidade: ");
                cidade[pos] = Console.ReadLine();
                Console.Write("Nova Idade: ");
                idade[pos] = Convert.ToInt32(Console.ReadLine());
                Console.Write("Novo Mês de Aniversário: ");
                mesAniversario[pos] = Convert.ToInt32(Console.ReadLine());
                Console.Write("Nova Profissão: ");
                profissao[pos] = Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Contato não encontrado");
            }
            Console.ReadKey();
        }

        static void ExcluirContato(ref String[] nome, ref String[] insta, ref String[] bairro, ref String[] cidade, ref int[] idade, ref int[] mesAniversario, ref String[] profissao, ref int tl)
        {
            Console.WriteLine("Excluir Contato");
            Console.Write("Insta do contato a ser excluído: ");
            string instaContato = Console.ReadLine();

            int pos = LocalizarContato(insta, tl, instaContato);

            if (pos != -1)
            {
                for (int i = pos; i < tl - 1; i++)
                {
                    nome[i] = nome[i + 1];
                    insta[i] = insta[i + 1];
                    bairro[i] = bairro[i + 1];
                    cidade[i] = cidade[i + 1];
                    idade[i] = idade[i + 1];
                    mesAniversario[i] = mesAniversario[i + 1];
                    profissao[i] = profissao[i + 1];
                }
                tl--;
                Console.WriteLine("Contato excluído com sucesso");
            }
            else
            {
                Console.WriteLine("Contato não encontrado");
            }
            Console.ReadKey();
        }

        static int LocalizarContato(String[] insta, int tl, String instaContato)
        {
            int pos = -1;
            for (int i = 0; i < tl; i++)
            {
                if (insta[i] == instaContato)
                {
                    pos = i;
                    break;
                }
            }
            return pos;
        }

        static void Main(string[] args)
        {
            String[] nome = new string[100];
            String[] insta = new string[100];
            String[] bairro = new string[100];
            String[] cidade = new string[100];
            int[] idade = new int[100];
            int[] mesAniversario = new int[100];
            String[] profissao = new string[100];

            int tl = 0;

            nome[tl] = "Eduardo";
            insta[tl] = "@ea.almeida11";
            bairro[tl] = "Ilha Amarela";
            cidade[tl] = "Salvador";
            idade[tl] = 18;
            mesAniversario[tl] = 9;
            profissao[tl] = "Técnico Informática";
            tl++;

            nome[tl] = "Dudu";
            insta[tl] = "@dudryz";
            bairro[tl] = "Rio Sena";
            cidade[tl] = "Salvador";
            idade[tl] = 15;
            mesAniversario[tl] = 9;
            profissao[tl] = "Gostoso";
            tl++;

            int op = 0;

            MostrarCabecalho();
            Console.WriteLine("Aperte enter para continuar!");

            Console.ReadLine();

            while (op != 6)
            {
                op = ExibirMenu();
                switch (op)
                {
                    case 1:
                        ExibirContato(nome, insta, bairro, cidade, idade, mesAniversario, profissao, tl);
                        break;
                    case 2:
                        InserirContato(ref nome, ref insta, ref bairro, ref cidade, ref idade, ref mesAniversario, ref profissao, ref tl);
                        break;
                    case 3:
                        AlterarContato(ref nome, ref insta, ref bairro, ref cidade, ref idade, ref mesAniversario, ref profissao, tl);
                        break;
                    case 4:
                        ExcluirContato(ref nome, ref insta, ref bairro, ref cidade, ref idade, ref mesAniversario, ref profissao, ref tl);
                        break;
                    case 5:
                        Console.WriteLine("Localizar Contato");
                        Console.Write("Insta: ");
                        string instaContato = Console.ReadLine();
                        int pos = LocalizarContato(insta, tl, instaContato);
                        if (pos != -1)
                        {
                            Console.WriteLine("Nome:{0} - Insta:{1} - Bairro:{2} - Cidade:{3} - Idade:{4} - Mês Aniversário:{5} - Profissão:{6}",
                                nome[pos], insta[pos], bairro[pos], cidade[pos], idade[pos], mesAniversario[pos], profissao[pos]);
                        }
                        else
                        {
                            Console.WriteLine("Contato não encontrado");
                        }
                        Console.ReadKey();
                        break;
                }
            }
        }
    }
}

